command: "echo Hello World!",
  // command: 'date -v1d +"%e"; date -v1d -v+1m -v-1d +"%d"; date +"%d%n%m%n%Y"',
  dayNames: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
    monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      offdayIndices: [6, 0], // Fr, Sa

        refreshFrequency: 5000,
          displayedDate: null,

            render: function () {
              return "<div class=\"cal-container\">\
  <div class=\"title\"></div>\
  <table>\
  <tr class=\"weekday\"></tr>\
  <tr class=\"midline\"></tr>\
  <tr class=\"date\"></tr>\
  </table>\
  </div>";
            },

style: `
  bottom: 0px
  left: 0px
  font-family: Helvetica Neue
  font-size: 11px
  font-weight: 500
  border-radius: 10px
  color: #fff
  -webkit-font-smoothing: antialiased;

  .cal-container
    border-radius: 4px
    //ackground: rgba(#000, 0.6)
    padding: 8px
    padding-top: 5px

  .title
    color: rgba(#fff, 0.7)
    font-size: 10px
    font-weight: 500
    padding-bottom: 4px
    text-transform uppercase

  table
    border-collapse: collapse

  td
    padding-left: 4px
    padding-right: 4px
    text-align: center

  .weekday td
    padding-top: 2px
    padding-bottom: 2px
    opacity: .6

  .date td
    padding-bottom: 0
    padding-top: 2px
    opacity: .5

  .today, .off-today
    opacity: 1

  .weekday .today,
  .weekday .off-today
    opacity: 1

  .date .today,
  .date .off-today
    opacity: 1

  .midline
    height: 3px
    background: rgba(#fff, .5)

  .midline .today
    background: rgba(#fff, 1)

  .midline .offday
    background: rgba(#ff6000, .5)

  .midline .off-today
    background: rgba(#444, .8)

  .offday, .off-today
    color: rgba(#ff6000, 1)
`,

  update: function (output, domEl) {
    // var date = output.split("\n"), firstWeekDay = date[0], lastDate = date[1], today = date[2], m = date[3]-1, y = date[4];

    // // DON'T MANUPULATE DOM IF NOT NEEDED
    // if(this.displayedDate != null && this.displayedDate == output) return;
    // else this.displayedDate = output;

    var date = new Date(), y = date.getFullYear(), m = date.getMonth(), today = date.getDate();

    // DON'T MANUPULATE DOM IF NOT NEEDED
    var newDate = [today, m, y].join("/");
    if (this.displayedDate != null && this.displayedDate == newDate) return;
    else this.displayedDate = newDate;

    var firstWeekDay = new Date(y, m, 1).getDay();
    var lastDate = new Date(y, m + 1, 0).getDate();

    var weekdays = "", midlines = "", dates = "";

    for (var i = 1, w = firstWeekDay; i <= lastDate; i++ , w++) {
      w %= 7;
      var isToday = (i == today), isOffday = (this.offdayIndices.indexOf(w) != -1);
      var className = "ordinary";
      if (isToday && isOffday) className = "off-today";
      else if (isToday) className = "today";
      else if (isOffday) className = "offday";

      weekdays += "<td class=\"" + className + "\">" + this.dayNames[w] + "</td>";
      midlines += "<td class=\"" + className + "\"></td>";
      dates += "<td class=\"" + className + "\">" + i + "</td>";
    };

    $(domEl).find(".title").html(this.monthNames[m] + " " + y);
    $(domEl).find(".weekday").html(weekdays);
    $(domEl).find(".midline").html(midlines);
    $(domEl).find(".date").html(dates);
  }